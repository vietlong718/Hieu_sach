package com.ute.bookstoreonlinebe.utils.enums;

public enum EnumLanguage {
    vn, en;
}
