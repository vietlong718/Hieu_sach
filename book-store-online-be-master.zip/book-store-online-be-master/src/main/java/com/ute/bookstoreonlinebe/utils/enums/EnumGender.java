package com.ute.bookstoreonlinebe.utils.enums;

public enum EnumGender {
    Male, Female;
}
