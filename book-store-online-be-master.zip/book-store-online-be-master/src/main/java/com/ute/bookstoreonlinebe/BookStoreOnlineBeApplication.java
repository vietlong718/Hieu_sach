package com.ute.bookstoreonlinebe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookStoreOnlineBeApplication {

    public static void main(String[] args) {
        SpringApplication.run(BookStoreOnlineBeApplication.class, args);
    }
}
