package com.ute.bookstoreonlinebe.models;

public class MyConstants {
    // Replace with your email here:
    public static final String MY_EMAIL = "zerodev247@gmail.com";

    // Replace password!!
    public static final String MY_PASSWORD = "buzylnegzpqswgkk";
}
