package com.ute.bookstoreonlinebe.dtos.card;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class CartDto {
//    private String userID;

    private List<CartDetail> cardDetail = new ArrayList<>();
}
