package com.ute.bookstoreonlinebe.utils.enums;

public enum EnumRole {
    ROLE_ADMIN, ROLE_MEMBER
}
